import POSInterface from "@/components/pos/POSInterface";

export default function PointOfSale() {
  return <POSInterface />;
}
